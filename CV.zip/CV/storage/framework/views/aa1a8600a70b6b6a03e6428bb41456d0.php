<!doctype html>

<html lang="en">
   
   
    <head>
       
       
        <!-- META -->
        <meta charset="utf-8">
        <meta name="robots" content="noodp">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
       
        <!-- PAGE TITLE -->
        <title>Jonathan CV</title>
       
        <!-- FAVICON -->
        <link rel="shortcut icon" href="assets/img/favicon.png">
       
        <!-- FONTS -->
        <link href="https://fonts.googleapis.com/css?family=Abril+Fatface%7CArapey&amp;subset=latin-ext" rel="stylesheet">
       
        <!-- STYLESHEETS -->
        <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
        <link rel="stylesheet" type="text/css" href="assets/css/main.css">
        
        
    </head>

   
    <body>
    
       
        <!-- PRELOADER -->
        <div class="preloader">
           
            <div class="spinner"></div>
            
        </div>
        <!-- /PRELOADER -->
    
        
        <!-- IMAGE CONTAINER -->
        <div class="image-container">
           
            <div class="background-img"></div>

        </div>
        <!-- /IMAGE CONTAINER -->


        <!-- CONTENT AREA -->
        <div class="content-area">


            <!-- CONTENT AREA INNER --> 
            <div class="content-area-inner">


                <!-- INTRO -->
                <section id="intro">


                    <!-- CONTAINER MID -->
                    <div class="container-mid">

                       
                        <!-- ANIMATION CONTAINER -->
                        <div class="animation-container animation-fade-down" data-animation-delay="0">
                        
                            <h1>My Name Is Jonathan Sukianto,</h1>
                        
                        </div>
                        <!-- /ANIMATION CONTAINER -->
                        
                        
                        <!-- ANIMATION CONTAINER -->
                        <div class="animation-container animation-fade-left" data-animation-delay="300">
                           
                            <p class="subline">i am a student at University International Batam</p>
                            
                        </div>
                        <!-- /ANIMATION CONTAINER -->
                        
                        
                        <!-- ANIMATION CONTAINER -->
                        <div class="animation-container animation-fade-up" data-animation-delay="600">
                           
                            <a href="#about" class="smooth-scroll">Learn More<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            
                        </div>
                        <!-- /ANIMATION CONTAINER -->


                    </div>
                    <!-- /CONTAINER MID -->


                </section>
                <!-- /INTRO -->


                <!-- ABOUT -->
                <section id="about">


                    <h3 class="headline scroll-animated-from-right">Why I can help you.</h3>
                    
                    <p class="scroll-animated-from-right">I can work under pressure and excel in teamworks</p>

                    


                </section>
                <!-- /ABOUT -->
                
                
                <!-- SERVICE -->
                <section id="service">


                    <h3 class="headline scroll-animated-from-right">Pendidikan</h3>
                    
                    
                    <!-- SERVICE LIST -->
                    <ul class="services-list">
                       
                       
                        <li class="scroll-animated-from-right"></i>Sekolah Dasar Pelita Nusantara</li>
                        <li class="scroll-animated-from-right"></i>SMP Pelita Nusantara</li>
                        <li class="scroll-animated-from-right"></i>SMA Pelita Nusantara</li>
                        
                        
                        
                    </ul>
                    <!-- /SERVICE LIST -->


                </section>
                <!-- /SERVICE -->
                
                
                
                
                <!-- CONTACT -->
                <section id="contact">


                    <h3 class="headline scroll-animated-from-right">Contact Me.</h3>
                    
                    
                    <!-- CONTACT LIST -->
                    <ul class="contact-list">
                       
                        <li class="scroll-animated-from-right"><i class="fa fa-mobile" aria-hidden="true"></i>082172555151</li>
                        <li class="scroll-animated-from-right"><i class="fa fa-envelope-o" aria-hidden="true"></i>jonathansukianto666@gmail.com</li>
                        
                    </ul>
                    <!-- /CONTACT LIST -->
                    
                    
                    <!-- CONTACT FORM --> 
                    <form id="contact-form" action="assets/php/contact.php" method="post">

                       
                        <input id="contact-form-name" type="text" name="name" class="form-control scroll-animated-from-right" placeholder="* Your Name">
                        
                        <input id="contact-form-email" type="text" name="email" class="form-control scroll-animated-from-right" placeholder="* Your Email">
                        
                        <!-- PHANTOM ELEMENT ( HONEYPOT CAPTCHA FOR SECURITY ) -->
                        <div class="fhp-input"><input id="contact-form-company" type="text" name="company" class="form-control"></div>
                        <!-- /PHANTOM ELEMENT ( HONEYPOT CAPTCHA FOR SECURITY ) -->
                        
                        <textarea id="contact-form-message" name="message" class="form-control scroll-animated-from-right" placeholder="* Your Message"></textarea>
                        
                        <button type="submit" class="form-control scroll-animated-from-right">Send Mail</button>
                        
                        <div class="success-message">* The Email was Sent Successfully!</div>

                   
                    </form>
                    <!-- /CONTACT FORM --> 


                </section>
                <!-- /CONTACT -->
                
                
                <!-- FOOTER -->
                <section id="footer">
                
                   
                    <!-- SOCIAL ICONS -->
                    <ul class="social-icons scroll-animated-from-right">
                       
                       
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        
                        
                    </ul>
                    <!-- /SOCIAL ICONS -->
                    

                    


                </section>
                <!-- /FOOTER -->


            </div>
            <!-- /CONTENT AREA INNER -->


        </div>
        <!-- /CONTENT AREA -->
        
        
        <!-- JAVASCRIPTS -->
        <script type="text/javascript" src="assets/js/plugins.js"></script>
        <script type="text/javascript" src="assets/js/main.js"></script>
   
   
    </body> 
    
    
</html><?php /**PATH C:\Users\LENOVO\Desktop\Laravel\CV\resources\views/welcome.blade.php ENDPATH**/ ?>